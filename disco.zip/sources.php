<?php $title='Sources';
include 'inc/header.php';
?>
 		<main>
        	<div class="row">
            	<h2>Sources</h2>
                <p class="sources"> All information on this site was obtained using information gathered from the following sources.</p>
                <ul>
                	<a href="https://en.wikipedia.org/wiki/Jack_Johnson_%28musician%29" title="Jack Johnson Wikipedia"><li>Jack Johnson Wikipedia</li></a>
                    <a href="http://jackjohnsonmusic.com/band" title="Jack Johnson Official Website"><li>Jack Johnson Official Site</li></a>
                    <a href="https://en.wikipedia.org/wiki/Jack_Johnson_discography" title="Jack Johnson Wikipedia Discography"><li>Jack Johnson Wikipedia Discography</li></a>
                </ul>
            </div>
        </main>    
    <?php include 'inc/footer.php';?>
