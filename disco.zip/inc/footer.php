 <footer>
    	<div class="row">
        	<div class="sitemap col-xs-6 col-sm-2">
                <h4>Site Map</h4>
                <ul>
                    <a href="index.php" title="homepage"><li>Home</li></a>
                    <a href="discography.php" title="albums"><li>Albums</li></a>
                    <a href="sources.php" title="sources"><li>Sources</li></a>
                    <a href="shop.php" title="shop"><li>Shop</li></a>
                </ul>
            </div>
            <div class="social col-xs-6 col-sm-4">
            	<div class="row">
            	<h4 class="col-xs-12 col-sm-6">Let's Keep in Touch</h4>
                	<div class="buttons col-xs-12 col-sm-6">
                    <a href="http://www.twitter.com" class="twitter" title="twitter"><img src="imgs/twitter.svg" alt="follow us on twitter"></a>
                    <a href="http://www.instagram.com" class="instagram" title="Instagram"><img src="imgs/instagram.svg" alt="keep up with Jack on instagram"></a>	
                    </div>
            </div>              
            </div>
            <div class="disclaimer col-xs-12 col-sm-6">
            	<p>This site is for educational purposes only and is in no way affiliated with Jack Johnson</p>
                <p>Created by <a href="http://www.tommyhenry.net" title="Tommy Henry">Tommy Henry</a></p>
            </div>   
       </div>      
    </footer>  
    </div>
</body>
</html>
